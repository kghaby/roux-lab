#!/usr/bin/perl -w

$achome="~/antechamber-1.27/";
#$dockhome="~/scripts/tools";
$chgtype="am1";

my @mol2 = <*.mol2>;
foreach $i (@mol2) 
{
        my $title = $i.".".$chgtype;
        my $mtitle = $i."_m".".".$chgtype;
        my $stitle = $i;
        $stitle =~ s/\.mol2//;
        $stitle =~ s/jnk\.aff-//;
        $tmp = $stitle;
        $stitle = sprintf("m%03d", $tmp);
	my($global_count) = 0;
	my($local_count) = 0;
	open (MOL2, $i) || die "\nCannot open mol2_file '$i' \n";
	open (OUT, ">$i.$chgtype") || die "\nCannot open mol2_file '$i' \n";
 	
 	$seen_bond = 0;	
	LINE: while (<MOL2>) {
		if (/@<TRIPOS>BOND/) {
                  $seen_bond = 1;
                }
                if (/^\n$/) {
                  $seen_bond = 0;
                  next LINE;
                }
  		{
		chomp($_);
        	if ($_ =~ /^(@<TRIPOS>MOLECULE)/)
        		{
                	if( $local_count != 0 )
                		{
                    		print OUT "@<TRIPOS>SUBSTRUCTURE\n";
                    		print OUT "     1 UNK         1 TEMP              0 ****  ****    0 ROOT\n\n\n";
                		}
                	print OUT "$_\n";
                	$local_count++;
                	$global_count++;
        		}
        	if ($_ =~ /^(@<TRIPOS>MOLECULE)/ && $local_count > 1)
        		{
                	$local_count = 1;
        		next;
			}
        	if ($_ !~ /^(@<TRIPOS>MOLECULE)/ && $_ !~ /^(#######)/ && $local_count == 1 )
        		{
               		print OUT "$_\n" ;
               		next;
        		}
}		}
	print OUT "@<TRIPOS>SUBSTRUCTURE\n";
	print OUT "     1 UNK         1 TEMP              0 ****  ****    0 ROOT\n\n\n";
	print OUT "$_\n";
system "export ACHOME=$achome;
        export PATH=\$PATH:$achome/exe;
        antechamber  -rn $stitle -s 2 -i $title -fi mol2 -o $title  -fo charmm -c bcc;
#        antechamber  -pm ./gaff.dat -rn $stitle -s 2 -i $title -fi mol2 -o $mtitle  -fo charmm -c bcc;
        mv mopac.out $title.mopac.out;
        rm -f ANTECH* ATOMTYPE.INF mopac.in";
}
