#!/usr/bin/perl -w


$charmm_exec = "~/c34a2/exec/gnu/charmm";
$nwater = 148;

$workdir = $ENV{PWD};
chomp $workdir;

$lid = m019;
$dirname = "setup19";
$gaff = "jnk.aff-19.mol2.am1";

chdir $dirname;
  system("../bin/fe.pl --title jnk.aff --stitle $lid --nwater $nwater --gsbpf jnk.aff --gsbpdir ../gsbp --inputdir ../inputs --cpddata ../compounds/ --setupdir ../$dirname/  --gcmc  --miu -6.2  --ncycle 2  --minstep 100  --mcstep 1000  --mdstep 500 --charmm_exec $charmm_exec   --nmpol 2  --gaff $gaff  --pertmc  --wall_time 18:00:00  --cput 18:00:00  --scheduler pbs");
