#!/usr/bin/perl -w


$charmm_exec = "~/c34a2/exec/gnu/charmm";
$nwater = 148;

$workdir = $ENV{PWD};
chomp $workdir;

$lid = m019;
$dirname = "setup19";
$gaff = "jnk.aff-19.mol2.am1";

chdir $dirname;

system("/usr/bin/nohup ../bin/fe.pl --nosite --gaff $gaff --ltitle jnk.aff --ndihe 2  --stitle $lid --ligcrd jnk.aff_${lid}_eq_lig  --setupdir ~/tutorial/setup19  --inputdir ~/tutorial/inputs/ --cpddata ~/tutorial/compounds --rtf top_all22_prot_cmap.inp --param par_all22_prot_cmap.inp --minstep 100 --equ_len 5000 --wind_len 5000 --do_charge --do_disp --do_repulsive  --do_rmsd  --rmsd_elen 2000  --rmsd_wlen  5000  --charmm_exec $charmm_exec  --chempert --k_rmsd 10 --scheduler pbs --cput 02:00:00  --wall_time 02:00:00 --restart ../run0 >& solv_log&");
