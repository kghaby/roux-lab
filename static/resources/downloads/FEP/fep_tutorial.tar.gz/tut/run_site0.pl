#!/usr/bin/perl -w


$charmm_exec = "~/c34a2/exec/gnu/charmm";
$nwater = 148;

$workdir = $ENV{PWD};
chomp $workdir;

$lid = m019;
$dirname = "setup19";
$gaff = "jnk.aff-19.mol2.am1";

chdir $dirname;

system("/usr/bin/nohup ../bin/fe.pl --title jnk.aff  --gaff $gaff --stitle $lid  --ligcrd jnk.aff_${lid}_eq_lig  --setupdir ~/tutorial/setup19  --gsbpdir ~/tutorial/gsbp  --gsbpf jnk.aff  --inputdir ~/tutorial/inputs  --cpddata ~/tutorial/compounds/  --const_wlen 1000 --const_elen 2000 --wind_len 400 --equ_len 1000 --rmsd_elen 2000 --rmsd_wlen 5000 --k_rmsd 10 --angforce 200 --tangforce 200 --distforce 10 --minstep 100 --charmm_exec $charmm_exec  --chempert --scheduler pbs  --do_rmsd --do_const --do_charge --do_repulsive --do_disp  --wall_time 2:00:00  --cput 2:00:00  --pertmc  --miu -6.2  --fast gene  --mcstep 1000  --ncycle 2  >& site_log&");
