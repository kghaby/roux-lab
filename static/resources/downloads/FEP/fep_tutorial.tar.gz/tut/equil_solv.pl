#!/usr/bin/perl -w


$charmm_exec = "~/c34a2/exec/gnu/charmm";
$nwater = 148;

$workdir = $ENV{PWD};
chomp $workdir;

$lid = m019;
$dirname = "setup19";
$gaff = "jnk.aff-19.mol2.am1";

chdir $dirname;
  system("../bin/fe.pl --nosite --stitle $lid --nwater 400 --inputdir ../inputs --cpddata ../compounds/ --setupdir ../$dirname/   --charmm_exec $charmm_exec   --k_rmsd 10 --ltitle jnk.aff --ligcrd jnk.aff_${lid}_eq_lig --ndihe 2  --gaff $gaff  --equil 1000 --minstep 500  --wall_time 00:30:00  --cput  00:30:00   --scheduler pbs");
